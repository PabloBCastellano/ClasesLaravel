<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>API</title>
</head>
<body>
        
</body>
<script>
         var clave="2117032151"
        let id="2"
    ListarUsuarios();
    function CargarUsuarios(){
       
        let direccion = new URL('http://localhost/Laravel/Practica1/public/api/ListarUsuariosapi'),
        params = {id:id, clave:clave}
        Object.keys(params).forEach(key => direccion.searchParams.append(key, params[key]))
        //console.log(direccion)
        return fetch(direccion,{method:"GET"})
            .then(response=>response.json())
            .then(function(res){
                
                return res;
            }).catch(function(error){
                console.log(error)
            })
        }
    async function ListarUsuarios(){
        let Cargar=await CargarUsuarios();
        if(Cargar["ClaveApi"]==clave){
            console.log(Cargar["usuarios"]);
        }
        else{
            alert("NO tienes acceso a la pagina");
        }
        
        
        //console.log("El id del Usuario es "+Cargar[0]);
        //console.log("El token del Usuario es "+Cargar[1]);
        
}
</script>
</html>