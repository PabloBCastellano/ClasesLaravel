<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>API</title>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jq-3.3.1/jszip-2.5.0/dt-1.10.24/b-1.7.0/b-flash-1.6.5/b-html5-1.7.0/b-print-1.7.0/sl-1.3.2/datatables.min.css"/>
 
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jq-3.3.1/jszip-2.5.0/dt-1.10.24/b-1.7.0/b-flash-1.6.5/b-html5-1.7.0/b-print-1.7.0/sl-1.3.2/datatables.min.js"></script>
        <script type='text/javascript' src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>
        <script type='text/javascript' src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
</head>
<style>
td:first-child{
   display: flex;
}
.Contenedor{
    width: 100%;
    text-align: center;
    padding: 25px;

}

.dataTables_filter{

    margin-bottom: 25px;
}

#example{
    border:1px solid;
}
</style>
<body>
<div class="Contenedor">
        <table id="example" class="table table-bordered border-primary"  style="width:100%">
            <thead>
                <tr>
                    <th scope="col" >Nombre Usuario</th>
                    <th>Correo Usuario</th>
                    <th>Clave Usuario</th>
                </tr>
            </thead>
            <tbody>
            </tbody>

        </table>

</body>
<script>
         var clave="2117032151"
        let id="2"
    ListarUsuarios();
    function CargarUsuarios(){
       
        let direccion = new URL('http://localhost/Laravel/Practica1/public/api/ListarUsuariosapi'),
        params = {id:id, clave:clave}
        Object.keys(params).forEach(key => direccion.searchParams.append(key, params[key]))
        //console.log(direccion)
        return fetch(direccion,{method:"GET"})
            .then(response=>response.json())
            .then(function(res){
                
                return res;
            }).catch(function(error){
                console.log(error)
            })
        }
    async function ListarUsuarios(){
        let Cargar=await CargarUsuarios();
        if(Cargar["ClaveApi"]==clave){
            $('#example').DataTable( {
                dom: 'Bfrtip',
            data: Cargar["usuarios"],   
            columns: [
                { data: 'NombreUsuario' },
                { data: 'CorreoUsuario' },
                { data: 'ClaveUsuario' }
                
            ],
            buttons: [
                "copy","print",
                {
                extend: 'excelHtml5',
                title: 'DatosApi'
            },
            {
                extend: 'pdfHtml5',
                title: 'DatosApi'
            },
            {
                extend: 'csvHtml5',
                title: 'DatosApi'
            }
        ]
           
        });
            console.log(Cargar["usuarios"]);
        }
        else{
            alert("NO tienes acceso a la pagina");
        }
        
        
        //console.log("El id del Usuario es "+Cargar[0]);
        //console.log("El token del Usuario es "+Cargar[1]);
        
}
</script>
</html>